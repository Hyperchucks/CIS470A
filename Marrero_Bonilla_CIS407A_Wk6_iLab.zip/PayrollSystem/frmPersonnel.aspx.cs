﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class frmPersonnel : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        // When the page loads it will check if the security level is an A.
        if (Session["SecurityLevel"] == "A")
        {
            btnSubmit.Visible = true;
            // If the security level is A it will show the submit button otherwise the submit button will not be shown.
        }
        else
        {
            btnSubmit.Visible = false;
        }
    }


    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        // Variables for the Date for the user entries.
        DateTime dt1;
        DateTime dt2;

        // This will make the error textbox blank again and the entry textbox back to white color.
        lblError.Text = "";
        Boolean validatedState = false;

        // The next 5 validation controls check if there are left blank or filled with blank spaces and gives the error message.
        if (Request["txtFirstName"].ToString().Trim() == "")
        {
            txtFirstName.BackColor = System.Drawing.Color.Yellow;
            lblError.Text = "Must enter a First Name. ";
            validatedState = true;
        }
        else
        {
            txtFirstName.BackColor = System.Drawing.Color.White;
        }

        if (Request["txtLastName"].ToString().Trim() == "")
        {
            txtLastName.BackColor = System.Drawing.Color.Yellow;
            lblError.Text += "Must enter a Last Name. ";
            validatedState = true;
        }
        else
        {
            txtLastName.BackColor = System.Drawing.Color.White;
        }

        if (Request["txtPayRate"].ToString().Trim() == "")
        {
            txtPayRate.BackColor = System.Drawing.Color.Yellow;
            lblError.Text += "Must enter a Pay Rate. ";
            validatedState = true;
        }
        else
        {
            txtPayRate.BackColor = System.Drawing.Color.White;
        }

        if (Request["txtStartDate"].ToString().Trim() == "")
        {
            txtStartDate.BackColor = System.Drawing.Color.Yellow;
            lblError.Text += "Must enter a Start Date. ";
            validatedState = true;
        }

        if (Request["txtEndDate"].ToString().Trim() == "")
        {
            txtEndDate.BackColor = System.Drawing.Color.Yellow;
            lblError.Text += "Must enter an End Date. ";
            validatedState = true;
        }

        // First this method saves the dates into the dt1 and dt2 variables and then perform the second part described on next line.
        // Second part it is a compare method to ensure the end date is later than the start date and will make the text boxes background yellow color.
        if (txtStartDate.Text.Trim() != "" & txtEndDate.Text.Trim() != "")
        {
            
            dt1 = DateTime.Parse(txtStartDate.Text);
            dt2 = DateTime.Parse(txtEndDate.Text);


            
            if (DateTime.Compare(dt1, dt2) > 0)
            {
                txtStartDate.BackColor = System.Drawing.Color.Yellow;
                txtEndDate.BackColor = System.Drawing.Color.Yellow;
                lblError.Text += "The end date must be a later date than the start date.";
                validatedState = true;
            }
            else
            {
                // This will ensure that the background color goes back to white if the textbox is filled and no errors are found.
                txtStartDate.BackColor = System.Drawing.Color.White;
                txtEndDate.BackColor = System.Drawing.Color.White;
            }
        }

        // This method saves the data from the session and pass it to the frmPersonnelVerified.
        if (validatedState == false)
        {
            Session["txtFirstName"] = txtFirstName.Text;
            Session["txtLastName"] = txtLastName.Text;
            Session["txtPayRate"] = txtPayRate.Text;
            Session["txtStartDate"] = txtStartDate.Text;
            Session["txtEndDate"] = txtEndDate.Text;
            Response.Redirect("frmPersonnelVerified.aspx"); 
        }
       
       
    }

        
}