﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class frmMain : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        // Add your comments here
        clsDataLayer.SaveUserActivity(Server.MapPath("PayrollSystem_DB.accdb"), "frmPersonnel");

        

        if (Session["SecurityLevel"] == "A")
        {
            linkbtnCalculator.Visible = true;
            imgbtnCalculator.Visible = true;
            linkbtnViewPersonnel.Visible = true;
            imgbtnViewPersonnel.Visible = true;
            linkbtnSearch.Visible = true;
            imgbtnSearch.Visible = true;
            linkbtnNewEmployee.Visible = true;
            imgbtnNewEmployee.Visible = true;
            linkbtnViewUserActivity.Visible = true;
            imgbtnViewUserActivity.Visible = true;
            linkbtnEditEmployees.Visible = true;
            imgbtnEditEmployees.Visible = true;
            linkbtnManageUser.Visible = true;
            imgbtnManageUsers.Visible = true;
        }
        else
        {
            linkbtnEditEmployees.Visible = false;
            imgbtnEditEmployees.Visible = false;
            linkbtnViewUserActivity.Visible = false;
            imgbtnViewUserActivity.Visible = false;
            linkbtnNewEmployee.Visible = false;
            imgbtnNewEmployee.Visible = false;
            linkbtnManageUser.Visible = false;
            imgbtnManageUsers.Visible = false;
        }
    }
}