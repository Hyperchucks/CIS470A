﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class frmSalaryCalculator : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void btnCalculateSalary_Click(object sender, EventArgs e)
    {
        //Declare Variables to be extracted data and perform the calculation.
        double annualHours = 0.0;   //Will hold the numeric value of the Annual Hours from text box.
        double rate = 0.0;          //Will hold the numeric value of the Rate from text box.
        double salary = 0.0;        //Will hold the numeric value of the annual hours by the rate from the text boxes.

        //Extract values from the text boxes.
        annualHours = Double.Parse(txtAnnualHours.Text);
        rate = Double.Parse(txtPayRate.Text);

        //Perform the calculation using the values of the variables, which are the values from the text boxes.
        salary = annualHours * rate;

        //Display results by assigning values to the label on the form.
        lblAnnualSalary.Text = "Annual Salary is " + salary.ToString("C");
    }
}